/*	Public domain	*/

#ifndef _USE_AGAR_TYPES
# undef Uint
# undef Uchar
# undef Ulong
# undef Uint8
# undef Sint8
# undef Uint16
# undef Sint16
# undef Uint32
# undef Sint32
# undef Uint64
# undef Sint64
#endif /* _USE_AGAR_TYPES */
