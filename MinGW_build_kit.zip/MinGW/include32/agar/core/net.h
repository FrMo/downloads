/*	Public domain	*/

#ifndef _AGAR_CORE_NET_H_
#define _AGAR_CORE_NET_H_
#include <agar/core/net_command.h>
#include <agar/core/net_client.h>
#include <agar/core/net_server.h>
#endif /* _AGAR_CORE_NET_H_ */

