#ifndef HAVE_GCC
#define HAVE_GCC "yes"
#endif
