#ifndef _MK_HAVE_SETJMP
#define _MK_HAVE_SETJMP "yes"
#endif
