#ifndef HAVE_LONG_DOUBLE
#define HAVE_LONG_DOUBLE "yes"
#endif
