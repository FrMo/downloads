#ifndef OPENGL_LIBS
#define OPENGL_LIBS " -L/usr/local/lib -lopengl32 -lgdi32"
#endif
