#ifndef LOCALSTATEDIR
#define LOCALSTATEDIR "/usr/local/var"
#endif
