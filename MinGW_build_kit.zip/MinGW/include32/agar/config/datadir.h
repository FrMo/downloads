#ifndef DATADIR
#define DATADIR "/usr/local/share"
#endif
