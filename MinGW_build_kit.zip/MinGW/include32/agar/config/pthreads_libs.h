#ifndef PTHREADS_LIBS
#define PTHREADS_LIBS "-lpthread"
#endif
