#ifndef SDL_LIBS
#define SDL_LIBS "-L/usr/local/lib -lmingw32 -lSDLmain -lSDL -mwindows"
#endif
