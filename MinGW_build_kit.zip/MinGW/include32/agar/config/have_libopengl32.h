#ifndef HAVE_LIBOPENGL32
#define HAVE_LIBOPENGL32 "yes"
#endif
