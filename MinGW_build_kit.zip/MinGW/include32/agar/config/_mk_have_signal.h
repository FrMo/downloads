#ifndef _MK_HAVE_SIGNAL
#define _MK_HAVE_SIGNAL "yes"
#endif
