#ifndef MANDIR
#define MANDIR "/usr/local/man"
#endif
