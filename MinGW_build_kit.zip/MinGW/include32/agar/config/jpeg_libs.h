#undef JPEG_LIBS
