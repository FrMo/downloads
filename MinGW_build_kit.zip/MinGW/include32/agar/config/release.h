#ifndef RELEASE
#define RELEASE "Landscapes of Frozen Methane"
#endif
