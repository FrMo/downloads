#ifndef ENABLE_VG
#define ENABLE_VG "yes"
#endif
