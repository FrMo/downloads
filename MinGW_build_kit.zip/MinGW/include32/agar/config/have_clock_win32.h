#ifndef HAVE_CLOCK_WIN32
#define HAVE_CLOCK_WIN32 "yes"
#endif
