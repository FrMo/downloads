#undef HAVE_SSE
