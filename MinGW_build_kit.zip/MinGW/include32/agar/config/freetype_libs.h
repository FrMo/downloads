#ifndef FREETYPE_LIBS
#define FREETYPE_LIBS "-L/usr/local/lib -lfreetype"
#endif
