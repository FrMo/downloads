#ifndef HAVE_LONG_LONG
#define HAVE_LONG_LONG "yes"
#endif
