#ifndef SHAREDIR
#define SHAREDIR "/usr/local/share/agar"
#endif
