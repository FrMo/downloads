#ifndef PTHREADS_XOPEN_LIBS
#define PTHREADS_XOPEN_LIBS "-lpthread"
#endif
