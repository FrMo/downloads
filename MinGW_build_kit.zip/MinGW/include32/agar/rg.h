/*	Public domain	*/

#ifndef _AGAR_RG_PUBLIC_H_
#define _AGAR_RG_PUBLIC_H_
#define _AGAR_RG_PUBLIC
#include <agar/core/core_begin.h>
#include <agar/rg/tileset.h>
#include <agar/rg/tileview.h>
#include <agar/rg/icons.h>
#include <agar/core/core_close.h>
#endif
