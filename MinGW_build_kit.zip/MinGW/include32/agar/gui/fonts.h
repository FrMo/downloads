#include <agar/gui/begin.h>
/* Begin generated block */
__BEGIN_DECLS
extern DECLSPEC AG_StaticFont agFontVera;
extern DECLSPEC AG_StaticFont agFontMinimal;
__END_DECLS
/* Close generated block */
#include <agar/gui/close.h>
