/*	Public domain	*/

#ifndef _AGAR_GUI_SDL_H_
#define _AGAR_GUI_SDL_H_

#include <agar/config/have_sdl.h>
#ifdef HAVE_SDL
#include <agar/gui/drv_sdl_common.h>
#endif

#endif /* _AGAR_GUI_SDL_H_ */
